#! /bin/bash

. venv/bin/activate
pip3 install -r requirements.txt
